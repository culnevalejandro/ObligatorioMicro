Anotar los cambios realizados en README.md cuando no estemos trabajando los tres juntos
